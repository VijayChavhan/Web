﻿using OpenQA.Selenium;
//using OpenQA.Selenium.Support.PageObjects;
// CS0618.cs
using OpenQA.Selenium.Support.UI;
using SeleniumExtras.PageObjects;
using System.Threading;

namespace myfirstproject.pageObjectsClasses
{
    public class PersonalInformationPage
    {
        
      IWebDriver driver;
        
        private IWebElement Gender => driver.FindElement(By.XPath("//*[@for='id_gender1']"));

        
        private IWebElement FirstNameTextbox => driver.FindElement(By.XPath("//*[@id='customer_firstname']"));

       
        private IWebElement LastNameTextbox => driver.FindElement(By.XPath("//*[@id='customer_lastname']"));

       
        private IWebElement PasswordTextbox => driver.FindElement(By.XPath("//*[@id='passwd']"));

        private IWebElement DaydropdownButton => driver.FindElement(By.XPath("//*[@id='uniform-days']"));

       
        private IWebElement MonthsdropdownButton => driver.FindElement(By.XPath("//*[@id='months']"));

        
        private IWebElement YeardropdownButton => driver.FindElement(By.XPath("//*[@id='years']"));

       
        private IWebElement AFirstnameTextBox => driver.FindElement(By.XPath("//*[@id='firstname']"));

        
        private IWebElement ALastNameTextBox => driver.FindElement(By.XPath("//*[@id='lastname']"));

       
        private IWebElement CompanyTextBox => driver.FindElement(By.XPath("//*[@id='company']"));

        
        private IWebElement AddressTextBox => driver.FindElement(By.XPath("//*[@id='address1']"));

      
        private IWebElement AreaTextBox => driver.FindElement(By.XPath("//*[@id='address2']"));

       
        private IWebElement cityTextBox => driver.FindElement(By.XPath("//*[@id='city']"));

     
        private IWebElement StateTextBox => driver.FindElement(By.XPath("//*[@id='id_state']"));

      
        private IWebElement postTextBox => driver.FindElement(By.XPath("//*[@id='postcode']"));
       public PersonalInformationPage(IWebDriver driver)
        {
            this.driver = driver;
            
            
        }
        public void UserPerformActionOnPersonalInformationpage()
        {
            Thread.Sleep(5000);
            Gender.Click();
            Thread.Sleep(5000);
            FirstNameTextbox.Click();
            Thread.Sleep(5000);
            FirstNameTextbox.Clear();
            Thread.Sleep(5000);
            FirstNameTextbox.SendKeys("vijay");
            Thread.Sleep(5000);
            LastNameTextbox.Click();
            Thread.Sleep(5000);
            LastNameTextbox.Clear();
            Thread.Sleep(5000);
            LastNameTextbox.SendKeys("Marathe");
            Thread.Sleep(5000);
            PasswordTextbox.Click();
            Thread.Sleep(5000);
            PasswordTextbox.Clear();
            Thread.Sleep(5000);
            PasswordTextbox.SendKeys("Password");
            Thread.Sleep(5000);
            new SelectElement(DaydropdownButton).SelectByText("13");
            Thread.Sleep(5000);
            new SelectElement(MonthsdropdownButton).SelectByText("October");
            Thread.Sleep(5000);
            new SelectElement(YeardropdownButton).SelectByText("1995");
            Thread.Sleep(5000);
            AFirstnameTextBox.Click();
            AFirstnameTextBox.Clear();
            AFirstnameTextBox.SendKeys("vijay");
            Thread.Sleep(5000);
            ALastNameTextBox.Click();
            ALastNameTextBox.Clear();
            ALastNameTextBox.SendKeys("Marathe");
            Thread.Sleep(5000);
            CompanyTextBox.Click();
            CompanyTextBox.Clear();
            CompanyTextBox.SendKeys("XYZ");
            Thread.Sleep(5000);
            AddressTextBox.Click();
            AddressTextBox.Clear();
            AddressTextBox.SendKeys("A/P Xyz ");
            Thread.Sleep(5000);
            AreaTextBox.Click();
            AreaTextBox.Clear();
            AreaTextBox.SendKeys("ABC chowk");
            Thread.Sleep(5000);
            cityTextBox.Click();
            cityTextBox.Clear();
            cityTextBox.SendKeys("PQR");
            Thread.Sleep(5000);
            new SelectElement(StateTextBox).SelectByText("Ohio");
            Thread.Sleep(5000);
            postTextBox.Click();
            Thread.Sleep(5000);
            postTextBox.Clear();
            Thread.Sleep(5000);
            postTextBox.SendKeys("43056");
        }
            
        }
}
