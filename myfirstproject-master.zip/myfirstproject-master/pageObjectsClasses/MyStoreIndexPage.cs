﻿using System;
using myfirstproject;
using myfirstproject.pageObjectsClasses;
using OpenQA.Selenium;
//obsolete using OpenQA.Selenium.Support.PageObjects;
using SeleniumExtras.PageObjects;
//OpenQA.Selenium.Internal.IWrapsElement;
using OpenQA.Selenium.Internal;

public class MyStoreIndexPage 
{
    IWebDriver driver;
    private IWebElement SignInButton => driver.FindElement(By.LinkText("http://automationpractice.com/index.php?controller=my-account"));

    // public IWebElement SignInButton1 { get { return this.SignInButton; } }
    public MyStoreIndexPage(IWebDriver driver)
    {
        this.driver = driver;
       
       
    }



    public void verifyuserlandingonMyStoreIndexPage()
    { 

        var title = driver.Title;
        
        if (driver.Title.Equals("My Store")){
            Console.WriteLine("user landing on My Store IndexPage");
            Console.WriteLine(title);
            Console.ReadLine();
        }
        else
        {
            Console.WriteLine("user not landing on My Store IndexPage");
        }
    }

    public RegistrationPage Userclickonsigninbutton()
    {
        
        SignInButton.Click();
        return new RegistrationPage(driver);
    }


}

