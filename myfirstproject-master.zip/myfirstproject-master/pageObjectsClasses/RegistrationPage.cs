﻿using System;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium;

namespace myfirstproject.pageObjectsClasses
{
    public class RegistrationPage
    {
     
        IWebDriver driver;
        public RegistrationPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        private IWebElement CreateAccountText => driver.FindElement(By.XPath("//*[text()='Create an account']"));

        
        private IWebElement EmailTextBox => driver.FindElement(By.XPath("(//*[@class='is_required validate account_input form-control'])[1]"));


        
        private IWebElement CreateaccountButton => driver.FindElement(By.XPath("//i[@class='icon-user left']"));

        public void ToCheckUserNavigateToRegistationPage()
        {
            if (CreateAccountText.Equals("CREATE AN ACCOUNT"))
            {
                Console.WriteLine("user Navigate to Register page ");

            }
            else
            {
                Console.WriteLine("user Not Navigate to Register page ");
            }

        }
        public PersonalInformationPage UsterEnterEmailAndClickOnCreateAccountButton()
        {
            EmailTextBox.Click();
            EmailTextBox.Clear();
            EmailTextBox.SendKeys("Vijaychavhan@gmail.com");
            CreateaccountButton.Click();
            return new PersonalInformationPage(driver);
        }

        
    }
}
