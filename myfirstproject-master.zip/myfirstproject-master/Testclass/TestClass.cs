﻿using myfirstproject.pageObjectsClasses;
using NUnit.Framework;
namespace myfirstproject.Testclass
{
    [TestFixture]
   public  class TestClass:BaseClass
    {
        public static MyStoreIndexPage indexpage;
        public static RegistrationPage registrationPage;
        public static PersonalInformationPage personalInformationPage;

        public void LunchingWbowser()
        {
            openTheBrowser();
        }
        [Test]
        public void verifyUserNavigateToIndexPage()
        {
           var indexpage = new MyStoreIndexPage(driver);
            indexpage.verifyuserlandingonMyStoreIndexPage();
            var registrationPage  = indexpage.Userclickonsigninbutton();
        }

        [Test]
        public void VerifyUserNavigateToRegistrationPage()
        {
           var registrationPage = new RegistrationPage(driver);
            registrationPage.ToCheckUserNavigateToRegistationPage();
           var personalInformationPage=registrationPage.UsterEnterEmailAndClickOnCreateAccountButton();
        }

        [Test]
        public void VerifyNevigateToPersonalInformatiomAndAction()
        {
            var personalInformationPage = new PersonalInformationPage(driver);
            personalInformationPage.UserPerformActionOnPersonalInformationpage();

        }


        [TearDown]
        public void Teardown()
        {
            closedTheBrowser();
        }

        public static void Main(string[] arg)
        {
            TestClass test = new TestClass();
            test.openTheBrowser();
            test.verifyUserNavigateToIndexPage();
            test.VerifyUserNavigateToRegistrationPage();
            test.VerifyNevigateToPersonalInformatiomAndAction();
            test.Teardown();
        }

    }
}
