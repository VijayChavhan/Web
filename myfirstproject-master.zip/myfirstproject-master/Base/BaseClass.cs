﻿using System;
using System.Threading;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace myfirstproject
{
    public  class BaseClass
    {
        public  IWebDriver driver;
        [SetUp]
        public  void openTheBrowser()
        {
            var chromeOptions = new ChromeOptions();
            //chromeOptions.AddArguments("headless");

            
            driver = new ChromeDriver(chromeOptions);
            driver.Url = "http://automationpractice.com/index.php";
            
            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(15);
            driver.Manage().Timeouts().PageLoad=TimeSpan.FromSeconds(15);
            Thread.Sleep(10000);

        }

        [TearDown]
      public void closedTheBrowser()
        {     
            driver.Manage().Cookies.DeleteAllCookies();  
            driver.Close();
            driver.Quit();
        }
    }
}
